package listasLineares;

public abstract class TipoLista {
	
}
