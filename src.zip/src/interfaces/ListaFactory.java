package interfaces;

public interface ListaFactory<T> {
	public Lista<T> criarLista();
}
